//
//  RowScrollingCollectionView.h
//  Goodrich
//
//  Created by Zhixing Yang on 8/1/15.
//  Copyright (c) 2015 Visenze. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RowScrollingCollectionView : UICollectionView

@property (nonatomic) int categoryIndex;

@end
