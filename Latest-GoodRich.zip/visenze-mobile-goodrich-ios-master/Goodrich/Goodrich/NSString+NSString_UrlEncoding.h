//
//  NSString+NSString_UrlEncoding.h
//  Goodrich
//
//  Created by Sai on 6/18/15.
//  Copyright (c) 2015 Visenze. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (NSString_UrlEncoding)

- (NSString *)urlencode;

@end
