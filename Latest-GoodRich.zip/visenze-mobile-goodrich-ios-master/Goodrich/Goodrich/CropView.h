//
//  CropView.h
//  Goodrich
//
//  Created by Zhixing on 30/12/14.
//  Copyright (c) 2014 Visenze. All rights reserved.
//

#import "Constants.h"
#import <UIKit/UIKit.h>

@interface CropView : UIView

@end
