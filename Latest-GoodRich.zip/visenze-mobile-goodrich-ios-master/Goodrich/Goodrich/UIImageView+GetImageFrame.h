//
//  UIImageView+GetImageFrame.h
//  Goodrich
//
//  Created by Zhixing on 30/12/14.
//  Copyright (c) 2014 Visenze. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImageView (GetImageFrame)

- (CGRect)innerImageFrameInSuperview;

@end