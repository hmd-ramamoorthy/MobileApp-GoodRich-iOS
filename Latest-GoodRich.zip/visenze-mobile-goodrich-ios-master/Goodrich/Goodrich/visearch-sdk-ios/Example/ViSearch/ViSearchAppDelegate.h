//
//  ViSearchAppDelegate.h
//  ViSearch
//
//  Created by CocoaPods on 01/08/2015.
//  Copyright (c) 2014 Shaohuan Li. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViSearchAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
