//
//  DataLoadingExceptionDelegate.h
//  Goodrich
//
//  Created by Zhixing on 2/1/15.
//  Copyright (c) 2015 Visenze. All rights reserved.
//

@protocol DataLoadingExceptionDelegate <NSObject>

- (void) retryButtonClicked:(id)sender;

@end
