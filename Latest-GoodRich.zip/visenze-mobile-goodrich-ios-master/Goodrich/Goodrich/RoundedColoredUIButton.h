//
//  RoundedColoredUIButton.h
//  Goodrich
//
//  Created by Zhixing on 30/12/14.
//  Copyright (c) 2014 Visenze. All rights reserved.
//

#import "RoundedUIButton.h"

@interface RoundedColoredUIButton : RoundedUIButton

@end
