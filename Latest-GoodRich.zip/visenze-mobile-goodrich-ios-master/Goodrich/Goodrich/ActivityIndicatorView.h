//
//  ActivityIndicatorView.h
//  Goodrich
//
//  Created by Zhixing Yang on 18/12/14.
//  Copyright (c) 2014 Visenze. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ActivityIndicatorView : UIImageView

@end
