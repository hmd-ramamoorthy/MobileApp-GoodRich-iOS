//
//  HomeViewController.m
//  Goodrich
//
//  Created by Zhixing Yang on 16/12/14.
//  Copyright (c) 2014 Visenze. All rights reserved.
//

#import "HomeViewController.h"

@interface HomeViewController ()

@end

@implementation HomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
    AppDelegate* appDelegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
    [appDelegate.sidebarViewControllerDelegate setSideBarEnabled: NO];
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    AppDelegate* appDelegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
    [appDelegate.sidebarViewControllerDelegate setSideBarEnabled: YES];
}
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    if ([segue.identifier isEqualToString:@"SegueFromHomeToBrowsing"]) {
        BrowsingItemsViewController* vc = (BrowsingItemsViewController*)segue.destinationViewController;
        vc.browingType = BROWSING_ITEMS_TYPE_ALL;
    } else if ([segue.identifier isEqualToString:@"SegueFromHomeToFav"]){
        BrowsingItemsViewController* vc = (BrowsingItemsViewController*)segue.destinationViewController;
        vc.browingType = BROWSING_ITEMS_TYPE_FAVOURITE;
    }
}

#pragma mark - Button click events

- (IBAction)menuButtonClicked:(UIButton *)sender {
    // One of the buttons on the main page is clicked. Do nothing here.
    // The action is handled by segue.
}

// Override
- (IBAction)backButtonClicked:(id)sender{
    AppDelegate* appDelegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
    [appDelegate.sidebarViewControllerDelegate toggleSideBarButtonClicked];
}

@end
