//
//  UIViewController+AuthLogic.h
//  Goodrich
//
//  Created by Zhixing Yang on 16/12/14.
//  Copyright (c) 2014 Visenze. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface UIViewController (AuthLogic)

- (void) registerCurrentViewControllerNotification;

@end
