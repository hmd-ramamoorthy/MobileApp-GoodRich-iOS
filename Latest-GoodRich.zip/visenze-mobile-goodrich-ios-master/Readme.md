#Release Log

##Current Release

###Release date: 2015/07/08

- App version: 1.2.0
- Supported platform: iPhone 6 plus, iPhone 6, iPhone 5s, iPhone 4s

Update:
    
    1. Add whatsapp sharing function
    2. Fix crash issue
    3. Find similar and similar items only displayed for the same product category


---
##History

###Release date: 2015/05/05

- App version: 1.1.1
- Supported platform: iPhone 6 plus, iPhone 6, iPhone 5s, iPhone 4s

Update:

    1. Fix UI
    2. Fix upload bug on iPad
    3. Add focus for camera

###Release date: 2015/04/14
- App version: 1.1.0
- Supported platform: iPhone 6 plus, iPhone 6, iPhone 5s, iPhone 4s

Update: 

    1. Fix crop bug
    2. Add home button on result page and search page
    3. Change share function
    4. UI modification and bug fix
    5. Change certificate
    6. Turn off auto flash
    7. Change new relic account
    
###Release date: 2015/02/24
- App version: 1.0.5
- Supported platform: iPhone 6 plus, iPhone 6, iPhone 5s, iPhone 4s

Update: 

    1. Fix ui issues


###Release date: 2015/02/17
- App version: 1.0.4
- Supported platform: iPhone 6 plus, iPhone 6, iPhone 5s, iPhone 4s

Update: 

    1. Ready for internal testing


